Fèlix Arribas Pardo

https://github.com/felixarpa/LP-Haskell/tree/master/practica\#pràctica
