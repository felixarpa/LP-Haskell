module Files where
trainFile = "iris.train.txt"
testFile  = "iris.test.txt"